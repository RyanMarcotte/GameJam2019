﻿public enum TileType
{
	Ground,
	Stump,
	Tree,
	Log,
	Bush,
	NoiseSprite,
	ShakeSprite,
	Rock,
	House
}